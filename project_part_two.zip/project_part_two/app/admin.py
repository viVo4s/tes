from django.contrib import admin
from .models import DesignRequest, Category

admin.site.register(DesignRequest)
admin.site.register(Category)

